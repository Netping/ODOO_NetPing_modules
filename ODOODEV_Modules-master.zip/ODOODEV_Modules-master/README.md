# ODOODEV_Modules
Проект разработки кастомных модулей для Odoo
Документация проекта: https://netping.atlassian.net/wiki/spaces/PROJ/pages/3411312784/ODODEV+Odoo
