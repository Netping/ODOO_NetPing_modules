# -*- coding: utf-8 -*-
{
    'name' : 'Odoo_API_SQL',
    'version' : 'Epic2.S2.1',
    'summary': 'NetPing cutomized module Odoo_API_SQL',
    'author': 'NetPing',
    'sequence': 0,
    'description': """

Designed according to: https://netping.atlassian.net/browse/ODOODEV-10
with design instruction ID: DOC1.V1.S2

    """,
    'category': 'Customizations',
    'depends' : [],
    'data': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
