Odoo_API_SQL
------------------------

# -- Install --
1) Put soure cod of Odoo_API_SQL module to the addons path
2) Switch on developer mode
3) Update app list
4) Search and click to install Odoo_API_SQL module

# -- Usage --
Example of connection to this module from external code you can see in sqlrequest.py in current folder





